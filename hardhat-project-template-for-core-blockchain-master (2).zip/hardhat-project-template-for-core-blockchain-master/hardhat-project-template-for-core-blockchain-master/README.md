## Things you need to do:

- Project.sol file - Rename this file and add the solidity code inside it.
- deploy.js file - Add the deploy.js (javascript) code inside it.
- .env.example - Add the Private Key of your MetaMask Wallet's account.
- Readme.md file - Add the Readme content inside this file.
- package.json file – Replace the `"name"` property value from `"Project-Title"` to your actual project title. <br/>
*Example:* `"name": "crowdfunding-smartcontract"`
